#include <iostream> //para operaciones de entrada/salida.cout, cin
//#include <stdio.h>//para hacer operaciones, est�ndar, de entrada y salida, as� como la definici�n de tipos

#include <cmath> //  funciones matematicas comunes
//#include <cstdlib> 

#include <stdlib.h> //Nos permiten convertir cadenas de caracteres a n�meros, n�meros a cadenas de caracteres, n�meros con decimales a n�meros enteros, etc.
#include <iomanip> //Las funciones de ayuda para controlar el formato o la entrada y la salida
				   // setpresicion
#include <string.h> //trabajar con cadenas de caracteres
#include <time.h>   //contiene funciones para manipular y formatear la fecha y hora del sistema.
#define N 12

using namespace std;
void juego();
void distancia2();
void matriz();

 int main()
 {	
     bool repite = true;
     int op;
do {
	system("cls");
    cout<<"****************************"<<endl;
    cout<<"      MENU DE OPCIONES      "<<endl;
    cout<<"****************************"<<endl;
    cout<<"1. JUEGO AHORCADO           "<<endl;
    cout<<"2.-SALIR                    "<<endl;
    cout<<"****************************"<<endl;
    cout<<"QUE DESEA HACER? "<<endl;
    cin>>op;
switch(op){
	case 1:
		juego();break;
	case 2:
	      cout << "\nEl programa se cerrara" << endl;
	      cout << "\nVuelva pronto!\n" << endl;
          repite = false;
          system("pause/null"); // el programa se pone en pausa hasta que se presione la letra enter
		  break;
}
}while(repite);

system("pause");
	return 0;
}
//JUEGO DEL AHORCADO
void juego(){
char txt[9];
char datos[N][9]={
"anteojo","avioneta","zapallo","martir",
"espejo","anzuelo","heciano","tripode",
"insecto","agujero","carnada","cabeza"};
 
char dibuj[9][7]={
 "____",
 "|  |",
 "|  |",
 "|",
 "|",
 "|",
 "|",
 "|",
 "----"
};
 
struct pst{
 int pos;
 char part[5];
}
parts[7]={{3,"  O"},{4," /"},{4,"|"},
{4,"\\"},{5,"  |"},{6," /"},{6," \\"}};
 
 int n,m,o,p,i,j,r,eq=0;char lc,tmp[10];
 
 srand(time(NULL));
 o=rand()%N; //numeros aleatorios
 
 m=strlen(datos[o]);p=m-2;
 
 txt[0]=datos[o][0];txt[m-1]=datos[o][m-1];
 for(n=1;n<m-1;n++)txt[n]='_';txt[m]=0;
 cout<<"*****Ahorcado***** Vr. 1.0\n\n";tmp[0]=0;
 for(i=0;i<9;i++)printf("%s\n",dibuj[i]);
 
 do{
 
   for(j=0;j<strlen(tmp);j++){
     lc=tmp[j];r=p;
     for(n=1;n<m-1;n++)
       if(datos[o][n]==lc){
         txt[n]=lc;datos[o][n]='_';p--;
       }
     if(r==p){
       strcat(dibuj[parts[eq].pos],parts[eq].part);
       eq++;
     }
     for(i=0;i<9;i++)printf("%s\n",dibuj[i]);
   }
 
   if(eq>=7)break;
 
   if(p>0){
     cout<<"\nPalabra: %s - Ingrese 1 letra (* para terminar): "<<txt;
     cin>>tmp;
   }lc=tmp[0];
   system("cls");
 }while(lc!='*'&&p);
 
 if(!p)cout<<"\nPalabra: %s - Ganaste!!!\n\n"<<txt;
 else if(eq>=7)cout<<"\nPerdiste!!!\n\n";
 else cout<<"\nK c's Pap�??? Recatate!!!\n\n";
 
 system("PAUSE");	
 
}


