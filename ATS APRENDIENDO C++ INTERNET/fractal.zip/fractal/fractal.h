//---------------------------------------------------------------
//	Fractal.h
//---------------------------------------------------------------
//	Esau R.O
//---------------------------------------------------------------

#ifndef _FRACTALES_H_
#define _FRACTALES_H_


#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define TRUE	1
#define FALSE	0


#endif