//---------------------------------------------------------------
//	Mandel.c
//---------------------------------------------------------------
//	Fractal de Mandelbrot - Esau R.O
//---------------------------------------------------------------

#include "mandel.h"
#include "graficos.h"


int Mandelbrot (double fX1, double fY1, double fX2, double fY2, int nLimite)
{
	int		max_x,	max_y,
			k,		p,		q,
			pasos,	terminar,
			color = 1;

	double	paso_x, paso_y,
			pos_x,	pos_y,
			iter_x, iter_y,
			temp_x;

	char 	c;

	cleardevice();

	max_x = getmaxx();
	max_y = getmaxy();

	paso_x = (fX2 - fX1) / max_x;
	paso_y = (fY2 - fY1) / max_y;

	for (q = 64; q <= nLimite; q += 64)
	{
		for (k = 0; k <= max_x; k++)
		{
			for (p = 0; p <= max_y; p++)
			{
				pos_x = fX1 + k * paso_x;
				pos_y = fY2 - p * paso_y;

				iter_x = 0.0;
				iter_y = 0.0;

				terminar = FALSE;
				pasos = 0;

				while (! terminar)
				{
					temp_x = (iter_x * iter_x) - (iter_y * iter_y) + pos_x;

					iter_y = 2 * (iter_x * iter_y) + pos_y;

					iter_x = temp_x;

					pasos++;

					if ((iter_x * iter_x + iter_y * iter_y) >= 4.0)
					{
						terminar = TRUE;
					}

					if (pasos >= q)
					{
						terminar = TRUE;
					}
				}

				if (pasos < q)
				{

					color = (pasos - 1) % 28 + 1;

					if (color > 15)
					{
						color = 30 - color;
					}

					putpixel (k, p, color);
				}
			}

			if (kbhit())
			{
				getch();

				return FALSE;
			}
		}
	}

	return TRUE;
}