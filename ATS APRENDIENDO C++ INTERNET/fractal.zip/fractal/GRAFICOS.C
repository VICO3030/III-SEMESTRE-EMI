//---------------------------------------------------------------
//	Graficos.c
//---------------------------------------------------------------
//	Esau R.O
//---------------------------------------------------------------

#include "graficos.h"
#include "fractal.h"


int gzn_color[16][3] = {{   0,  0,	0},
						{  10,  8, 23},
						{  13, 16, 36},
						{  15, 18, 41},
						{  17, 21, 46},
						{  18, 23, 49},
						{  20, 26, 50},
						{  22, 29, 52},
						{  24, 35, 55},
						{  22, 40, 58},
						{  20, 45, 60},
						{  17, 46, 61},
						{  16, 47, 62},
						{  25, 52, 62},
						{  38, 58, 63},
						{  63, 63, 63}};


int gn_GrillaActiva = FALSE;
int gn_Grilla_x;
int gn_Grilla_y;


extern double gf_x1;
extern double gf_y1;
extern double gf_x2;
extern double gf_y2;
extern double gn_pasos;


void	CambiarColoresPaleta (int opc)
{
	struct palettetype pal;
	int k;

	getpalette(&pal);

	if (pal.size == 16)
	{
		switch (opc)
		{
			case EX_C_GRIS:
				for (k = 0; k < 16; k++)
				{
					setrgbpalette (pal.colors[k], gzn_color[k][1], gzn_color[k][1], gzn_color[k][1]);
				}
				break;

			case EX_C_AZUL:
				for (k = 0; k < 16; k++)
				{
					setrgbpalette (pal.colors[k], gzn_color[k][0], gzn_color[k][1], gzn_color[k][2]);
				}
				break;

			case EX_C_ROJO:
				for (k = 0; k < 16; k++)
				{
					setrgbpalette (pal.colors[k], gzn_color[k][2], k * 4, gzn_color[k][0]);
				}
				break;

			case EX_C_VERDE:
				for (k = 0; k < 16; k++)
				{
					setrgbpalette (pal.colors[k], k * 4, gzn_color[k][2], gzn_color[k][0]);
				}
				break;

			default:
				break;
		}
	}
}


int 	InicializarGraficos()
{
	int ControladorGrafico;
	int ModoGrafico;
	int CodigoError = 0;

	ControladorGrafico = VGA;
	ModoGrafico = VGAHI;

	initgraph (& ControladorGrafico, & ModoGrafico, RUTA_BGI);

	CodigoError = graphresult();

	if (CodigoError != grOk)
	{
		printf ("\n No se encontro la carpeta del controlador BGI\n o no se pudo inicializar correctamente adaptador VGA.");
		printf ("\n %s\n", grapherrormsg (CodigoError));
		return FALSE;
	}
	else
	{
		CambiarColoresPaleta (EX_C_AZUL);
		return TRUE;
	}
}


void	Cuadriculado()
{
	setcolor (7);

	line (0, 0, 639, 0);
	line (0, 119, 639, 119);
	line (0, 239, 639, 239);
	line (0, 359, 639, 359);
	line (0, 479, 639, 479);

	line (0, 0, 0, 479);
	line (159, 0, 159, 479);
	line (319, 0, 319, 479);
	line (479, 0, 479, 479);
	line (639, 0, 639, 479);
}


void	MiniCuadriculado()
{
	int x1, y1, x2, y2;

	setcolor (14);

	if (gn_Grilla_x == 1)
	{
		x1 = 0;
		x2 = 319;
	}
	else
	{
		x1 = 160 * (gn_Grilla_x - 1) - 1;
		x2 = 160 * (gn_Grilla_x + 1) - 1;
	}

	if (gn_Grilla_y == 3)
	{
		y1 = 239;
		y2 = 0;
	}
	else
	{
		y1 = 479 - 120 * (gn_Grilla_y - 1);
		y2 = 479 - 120 * (gn_Grilla_y + 1);
	}

	line (x1, y1, x1, y2);
	line (x1, y2, x2, y2);
	line (x2, y2, x2, y1);
	line (x2, y1, x1, y1);
}


int 	DibujarGrilla()
{
	if (gn_GrillaActiva == FALSE)
	{
		Cuadriculado();

		gn_Grilla_x = 1;
		gn_Grilla_y = 1;

		MiniCuadriculado();

		gn_GrillaActiva = TRUE;

		return TRUE;
	}

	return FALSE;
}


int 	GrillaIzquierda()
{
	if ((gn_GrillaActiva == TRUE) && (gn_Grilla_x > 1))
	{
		-- gn_Grilla_x;
		Cuadriculado();
		MiniCuadriculado();
		return TRUE;
	}

	return FALSE;
}


int 	GrillaDerecha()
{
	if ((gn_GrillaActiva == TRUE) && (gn_Grilla_x < EX_MAX_GRILLA))
	{
		++ gn_Grilla_x;
		Cuadriculado();
		MiniCuadriculado();
		return TRUE;
	}

	return FALSE;
}


int 	GrillaArriba()
{
	if ((gn_GrillaActiva == TRUE) && (gn_Grilla_y < EX_MAX_GRILLA))
	{
		++ gn_Grilla_y;
		Cuadriculado();
		MiniCuadriculado();
		return TRUE;
	}

	return FALSE;
}


int 	GrillaAbajo()
{
	if ((gn_GrillaActiva == TRUE) && (gn_Grilla_y > 1))
	{
		-- gn_Grilla_y;
		Cuadriculado();
		MiniCuadriculado();
		return TRUE;
	}

	return FALSE;
}


int 	Zoom (int (* fnc_fractal)(double, double, double, double, int))
{
	double dx, dy;

	if (gn_GrillaActiva == FALSE)
	{
		return FALSE;
	}

	dx = (gf_x2 - gf_x1) / 4;
	dy = (gf_y2 - gf_y1) / 4;

	gf_x1 = gf_x1 + (gn_Grilla_x - 1) * dx;
	gf_y1 = gf_y1 + (gn_Grilla_y - 1) * dy;

	gf_x2 = gf_x1 + 2 * dx;
	gf_y2 = gf_y1 + 2 * dy;

	gn_GrillaActiva = FALSE;

	if (gn_pasos < 10240)
	{
		gn_pasos += 256;
	}

	return ((* fnc_fractal) (gf_x1, gf_y1, gf_x2, gf_y2, gn_pasos));
}
