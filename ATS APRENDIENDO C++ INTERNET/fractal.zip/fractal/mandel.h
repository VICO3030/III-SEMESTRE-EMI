//---------------------------------------------------------------
//	Mandel.h
//---------------------------------------------------------------
//	Esau R.O
//---------------------------------------------------------------

#ifndef _MANDEL_H_
#define _MANDEL_H_

#include "fractal.h"

	int Mandelbrot (double fX1, double fY1, double fX2, double fY2, int nLimite);

#endif