//---------------------------------------------------------------
//	Fractal.c
//---------------------------------------------------------------
//	FRACTALES - Esau R.O
//---------------------------------------------------------------

#include "fractal.h"
#include "mandel.h"
#include "graficos.h"

#include <dos.h>

double gf_x1;
double gf_y1;
double gf_x2;
double gf_y2;
double gn_pasos;


void Pausa()
{
	while (kbhit())
	{
		getch();
	}

	getch();
}

int main()
{
	char c;

	if (! InicializarGraficos())
	{
		exit(1);
	}

	gf_x1 = -2.5;
	gf_y1 = -1.2;
	gf_x2 = 0.7;
	gf_y2 = 1.2;
	gn_pasos = 256;

	Mandelbrot (gf_x1, gf_y1, gf_x2, gf_y2, gn_pasos);

	while (TRUE)
	{
		if (kbhit())
		{
			c = getch();

			switch (c)
			{
				case 'Q':
				case 'q':
					goto SALIR;

				case '1':
					CambiarColoresPaleta (EX_C_GRIS);
					break;

				case '2':
					CambiarColoresPaleta (EX_C_ROJO);
					break;

				case '3':
					CambiarColoresPaleta (EX_C_VERDE);
					break;

				case '4':
					CambiarColoresPaleta (EX_C_AZUL);
					break;

				case 'C':
				case 'c':
					DibujarGrilla ();
					break;

				case 'A':
				case 'a':
					GrillaIzquierda();
					break;

				case 'W':
				case 'w':
					GrillaArriba();
					break;

				case 'S':
				case 's':
					GrillaAbajo();
					break;

				case 'D':
				case 'd':
					GrillaDerecha();
					break;

				case 'Z':
				case 'z':
					Zoom (& Mandelbrot);
					break;
			}
		}

		delay (100);
	}

SALIR:

	closegraph();

	return 0;
}
