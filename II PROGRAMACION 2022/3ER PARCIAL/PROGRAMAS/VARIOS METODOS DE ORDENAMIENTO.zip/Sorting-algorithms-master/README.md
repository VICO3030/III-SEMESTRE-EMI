# Sort algorithms in C ++ | Metodos de ordenamiento en C++

##### Contactame

[Facebook](https://www.facebook.com/zurckzte) 

[YouTube](https://www.youtube.com/user/noezurckz)

[Twitter](https://twitter.com/Zurckz)

***

<dl>
  <dt>Metodos de ordenacion en el lenguajde de programación C++</dt>
  <dd>Burbuja</dd>
	<dd>Shell</dd>
	<dd>Selección</dd>
	<dd>Inserccíon directa</dd>
	<dd>Ordenamiento rapido</dd>
	<dd>Radix</dd>
</dl>
